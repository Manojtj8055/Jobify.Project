package com.xworkz.breakfast.dto;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="breakfast")
public class BreakfastDTO {
	
	@Id
	private int id;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}

	private String name;
	private int price;
	private int quantity;
	private String type;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	
		
	
	@Override
	public String toString() {
		return "BreakfastDTO [id=" + id + ", name=" + name + ", price=" + price + ", quantity=" + quantity + ", type="
				+ type + "]";
	}
	public BreakfastDTO(int id, String name, int price, int quantity, String type) {
		super();
		this.id = id;
		this.name = name;
		this.price = price;
		this.quantity = quantity;
		this.type = type;
	}
	public BreakfastDTO() {
		
	}
	

}
