package com.xworkz.breakfast.dto;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class BreakfastRunner {

	public static void main(String[] args) {

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("breakfast-connection");
		EntityManager em = emf.createEntityManager();
		 EntityTransaction et = em.getTransaction();
		
		 BreakfastDTO bf = new BreakfastDTO(4, "Poori", 50, 1, "Veg");
		 et.begin();
//		 BreakfastDTO data = em.find(BreakfastDTO.class, 3);
//		 System.out.println(data);
		 em.persist(bf);
		 et.commit();
		 
		 emf.close();
		 em.close();
		 
		 
	}

}
