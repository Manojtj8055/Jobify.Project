package com.xworkz.jobify.enumm;

public enum AccountType {  
	JOBSEEKER,JOBPROVIDER

}
