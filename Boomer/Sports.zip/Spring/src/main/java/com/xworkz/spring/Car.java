package com.xworkz.spring;

public class Car implements Vehicle{

	@Override
	public void start() {
		System.out.println("Car Starts..");
		
	}

}
