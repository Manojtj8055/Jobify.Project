package com.xworkz.spring;

public interface Vehicle {

	void start() ;
	
}
